package com.hansoolabs.flutter_video_list_sample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
